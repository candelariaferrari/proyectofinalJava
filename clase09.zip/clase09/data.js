const datosProductos =[{id: "Diseño gráfico", nombre:"Logo", precio: 1000 },
                 {id: "Diseño gráfico", nombre:"Identidad visual", precio: 6000 },
                 {id: "Diseño gráfico", nombre:"Flyer", precio: 700 },
                 {id: "Diseño gráfico", nombre:"Redes sociales", precio: 5500 },
                 {id: "Diseño web", nombre:"Landing page", precio: 10000 },
                 {id: "Diseño web", nombre:"Web corporativa", precio: 45000 },
                 {id: "Diseño web", nombre:"Landing subcripcion", precio: 5000 }
                ];
