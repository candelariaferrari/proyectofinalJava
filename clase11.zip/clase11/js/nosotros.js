let dataNosotros = [{
    "id": 1,
    "nombre": "Diego Ponce",
    "avatar": "./img/foto-03.png",
    "puesto": "CEO",
    "linkedin": "https://www.linkedin.com/"
  }, {
    "id": 2,
    "nombre": "Marianela Bonino",
    "avatar": "./img/foto-01.png",
    "puesto": "Desarrolladora web",
    "linkedin": "https://www.linkedin.com/"  
  },
    {
    "id": 3,
    "nombre": "Carlos Massari",
    "avatar": "./img/foto-04.png",
    "puesto": "Marketing",
    "linkedin": "https://www.linkedin.com/"
  }, {
    "id": 4,
    "nombre": "Fabiana Sandone",
    "avatar": "./img/foto-02.png",
    "puesto": "Diseñadora gráfica",
    "linkedin": "https://www.linkedin.com/"
  },];